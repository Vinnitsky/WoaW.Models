﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Angle.Controllers
{
    public class ElementsController : Controller
    {
        public ActionResult Animations()
        {
            return View();
        }
        public ActionResult Buttons()
        {
            return View();
        }
        public ActionResult Carousel()
        {
            return View();
        }
        public ActionResult Colors()
        {
            return View();
        }
        public ActionResult DropdownAnimations()
        {
            return View();
        }
        public ActionResult Grid()
        {
            return View();
        }
        public ActionResult GridMasonry()
        {
            return View();
        }
        public ActionResult IconsFont()
        {
            return View();
        }
        public ActionResult IconsWeather()
        {
            return View();
        }
        public ActionResult Notifications()
        {
            return View();
        }
        public ActionResult Nestable()
        {
            return View();
        }
        public ActionResult Sortable()
        {
            return View();
        }
        public ActionResult Panels()
        {
            return View();
        }
        public ActionResult Portlets()
        {
            return View();
        }
        public ActionResult Spinners()
        {
            return View();
        }
        public ActionResult Typo()
        {
            return View();
        }
        public ActionResult SweetAlert()
        {
            return View();
        }
        public ActionResult Tour()
        {
            return View();
        }

    }
}