﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Angle.Controllers
{
    public class ExtrasController : Controller
    {
        public ActionResult Calendar()
        {
            return View();
        }
        public ActionResult Invoice()
        {
            return View();
        }
        public ActionResult Mailbox()
        {
            return View();
        }
        public ActionResult UserProfile()
        {
            return View();
        }
        public ActionResult Search()
        {
            return View();
        }
        public ActionResult Timeline()
        {
            return View();
        }
        public ActionResult Todo()
        {
            return View();
        }
        public ActionResult Contacts()
        {
            return View();
        }
        public ActionResult ContactDetails()
        {
            return View();
        }
        public ActionResult Projects()
        {
            return View();
        }
        public ActionResult ProjectDetails()
        {
            return View();
        }
        public ActionResult TeamViewer()
        {
            return View();
        }
        public ActionResult SocialBoard()
        {
            return View();
        }
        public ActionResult VoteLinks()
        {
            return View();
        }
        public ActionResult BugTracker()
        {
            return View();
        }
        public ActionResult Faq()
        {
            return View();
        }
        public ActionResult HelpCenter()
        {
            return View();
        }
        public ActionResult Followers()
        {
            return View();
        }
        public ActionResult Settings()
        {
            return View();
        }
        public ActionResult Plans()
        {
            return View();
        }
        public ActionResult FileManager()
        {
            return View();
        }
    }
}