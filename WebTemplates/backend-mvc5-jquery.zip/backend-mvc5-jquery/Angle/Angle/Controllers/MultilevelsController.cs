﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Angle.Controllers
{
    public class MultilevelsController : Controller
    {
        public ActionResult Multilevel_1()
        {
            return View();
        }
        public ActionResult Multilevel_3()
        {
            return View();
        }
    }
}